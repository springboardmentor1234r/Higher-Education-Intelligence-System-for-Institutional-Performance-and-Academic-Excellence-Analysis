# EduVision_DV - Milestone 1 Output
Data Collection and Preparation (Modules 1 & 2)

## data/raw/ — Module 1: Raw datasets (untouched, exactly as uploaded)
- `qs_2025_raw.csv` — QS World University Rankings 2025
- `wur_2023_raw.csv` — World University Rankings 2023
- `the_2024_filtered_raw.csv` — THE World University Rankings 2024 (filtered from the
  2016-2026 source you uploaded, since your original THE-2024-only file was empty — see
  Known Deviations below)
- `world_bank_edstats_country_raw.csv` — World Bank country metadata
- NOT included (file size only, originals unmodified): `world_bank_edstats_data_raw.csv`
  (326MB) and `the_2016_2026_raw.csv` (1.7MB) — ask if you need these re-attached

## data/cleaned/ — Module 2: Cleaned datasets
- `qs_2025_cleaned.csv`, `the_2024_cleaned.csv`, `wur_2023_cleaned.csv` — each source cleaned
  independently: standardized column names, cleaned university/country names, numeric type
  conversion (including proper handling of rank bands like "601-610"), missing values
  documented (not zero-filled)
- `world_bank_education_cleaned.csv` — filtered to 7 documented indicators, reshaped to long
  format (country, year, indicator, value)
- `dim_university.csv` — master university table, `university_id` assigned to 3,226 unique
  universities (exact match on name+country only, no aggressive fuzzy matching)
- `dim_country.csv` — master country table, `country_id` assigned to 134 countries

## docs/
- `validation_report_summary.csv` — Module 1 Step 1 validation report (rows, columns, key
  columns, duplicates) for all 4 raw datasets, BEFORE cleaning
- `validation_report.txt` — same report with full missing-value breakdowns per column
- `validation_report_raw.json` — machine-readable version

## scripts/
- `01_validation_report.py` — generates the validation report
- `02a/02b/02c/02d_clean_*.py` — per-dataset cleaning scripts
- `03_build_master_ids.py` — university_id / country_id construction

## Key findings from this stage
- WUR 2023 raw file had 29 blank junk rows and 107 rows with missing university names
  (not true duplicate universities) — investigated and resolved in cleaning, not blindly dropped
- QS 2025 and WUR 2023 both use rank/score BANDS for lower performers (e.g. "601-610",
  "51.2-54.3") instead of single numbers — handled with separate exact/band fields so this
  data isn't silently lost to NaN
- University match rate across the 3 ranking sources (exact match only): 17.6% in all 3,
  33.8% in exactly 2, 48.5% in only 1 — honest rate, no forced fuzzy matching

## Known deviations from the original guide (documented, not hidden)
1. Your uploaded `TIMES_WorldUniversityRankings_2024-selected-columns.csv` contained only
   headers, no data — substituted with a Year=2024 filter of `THE_World_University_Rankings_2016-2026.csv`
2. QS 2025 file has only 10 columns (not ~28 as the guide's example describes) — no
   Overall_Score, Citations_per_Faculty_Score, etc. This affects KPI sourcing in Milestone 2.
