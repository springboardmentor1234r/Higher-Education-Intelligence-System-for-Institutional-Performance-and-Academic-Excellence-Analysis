"""Module 2 - Clean QS World University Rankings 2025"""
import pandas as pd
import re

df = pd.read_csv("data/raw/qs_2025_raw.csv")
print("BEFORE:", df.shape)

# 1. Standardize column names
df.columns = (df.columns.str.strip().str.lower()
              .str.replace(" ", "_").str.replace("-", "_").str.replace(".", "", regex=False))

# 2. Clean university names (keep a display version + a normalized matching key)
df["institution_name"] = df["institution_name"].astype(str).str.strip()
df["university_name_key"] = (
    df["institution_name"].str.lower()
    .str.replace(r"[^\w\s]", "", regex=True)
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)

# 3. Clean country/location names
df["location"] = df["location"].astype(str).str.strip()
country_map = {
    "usa": "united states", "us": "united states", "united states of america": "united states",
    "uk": "united kingdom", "great britain": "united kingdom",
    "south korea": "korea, south", "hong kong sar": "hong kong",
}
df["country_clean"] = df["location"].str.lower().str.strip().replace(country_map)
df["country_clean"] = df["country_clean"].str.title()

# 4. Convert numeric fields
# QS ranks are messy: exact ranks ("1","2"), tied ranks ("=12"), and band ranks for
# lower-ranked universities ("601-610", "1401+"). A band cannot become one true number,
# so we keep TWO fields: an exact numeric rank (NaN if banded) and a bracket label
# (for banded universities), documented explicitly rather than silently coerced to NaN.
def parse_rank(val):
    s = str(val).strip().replace("=", "")
    if re.fullmatch(r"\d+", s):
        return float(s), None          # exact numeric rank
    if re.fullmatch(r"\d+\+", s):
        return None, s                 # open-ended band e.g. "1401+"
    if re.fullmatch(r"\d+-\d+", s):
        return None, s                 # ranged band e.g. "601-610"
    return None, None                  # unknown/missing

for col in ["rank_2025", "rank_2024"]:
    parsed = df[col].apply(parse_rank)
    df[col + "_numeric"] = parsed.apply(lambda x: x[0])
    df[col + "_band"] = parsed.apply(lambda x: x[1])

df["academic_reputation_score"] = pd.to_numeric(df["academic_reputation_score"], errors="coerce")

# 5. Duplicate check (already confirmed 0 duplicate rows / 0 duplicate names in validation)
dup_rows = df.duplicated().sum()
dup_names = df["university_name_key"].duplicated().sum()
print(f"Duplicate rows: {dup_rows} | Duplicate university keys: {dup_names}")

# 6. Missing value documentation (do NOT zero-fill)
missing_summary = df.isnull().mean() * 100
print("\nMissing % after cleaning:")
print(missing_summary[missing_summary > 0])

# Save cleaned file
df.to_csv("data/cleaned/qs_2025_cleaned.csv", index=False)
print("\nSaved: data/cleaned/qs_2025_cleaned.csv | Final shape:", df.shape)
