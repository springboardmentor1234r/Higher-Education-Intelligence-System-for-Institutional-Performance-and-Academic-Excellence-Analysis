"""Module 2 - Clean THE World University Rankings 2024 (filtered from 2016-2026 source)"""
import pandas as pd
import re

df = pd.read_csv("data/raw/the_2024_filtered_raw.csv")
print("BEFORE:", df.shape)

# 1. Standardize column names
df.columns = (df.columns.str.strip().str.lower()
              .str.replace(" ", "_").str.replace("-", "_"))

# 2. Clean university names
df["name"] = df["name"].astype(str).str.strip()
df["university_name_key"] = (
    df["name"].str.lower()
    .str.replace(r"[^\w\s]", "", regex=True)
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)

# 3. Clean country names
df["country"] = df["country"].astype(str).str.strip()
country_map = {
    "usa": "united states", "us": "united states", "united states of america": "united states",
    "uk": "united kingdom", "great britain": "united kingdom",
    "south korea": "korea, south", "hong kong sar": "hong kong",
}
df["country_clean"] = df["country"].str.lower().str.strip().replace(country_map).str.title()

# 4. Convert numeric/percentage fields
# "International Students" is stored as a percent string e.g. "26%" -> must become numeric, NOT left as text
df["international_students_pct"] = pd.to_numeric(
    df["international_students"].astype(str).str.replace("%", "", regex=False), errors="coerce"
)

# Female:Male ratio e.g. "33 : 67" -> keep as female_pct numeric for usability, document transformation
def parse_ratio(val):
    s = str(val)
    m = re.match(r"\s*(\d+)\s*:\s*(\d+)\s*", s)
    if m:
        f, m_ = int(m.group(1)), int(m.group(2))
        if f + m_ > 0:
            return round(f / (f + m_) * 100, 2)
    return None

df["female_pct"] = df["female_to_male_ratio"].apply(parse_ratio)

for col in ["overall_score", "teaching", "research_environment", "research_quality",
            "industry_impact", "international_outlook", "students_to_staff_ratio"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# 5. Duplicates
dup_rows = df.duplicated().sum()
dup_names = df["university_name_key"].duplicated().sum()
print(f"Duplicate rows: {dup_rows} | Duplicate university keys: {dup_names}")

# 6. Missing value report
missing_summary = df.isnull().mean() * 100
print("\nMissing % after cleaning:")
print(missing_summary[missing_summary > 0])

df.to_csv("data/cleaned/the_2024_cleaned.csv", index=False)
print("\nSaved: data/cleaned/the_2024_cleaned.csv | Final shape:", df.shape)
