"""
EduVision_DV - Module 1: Dataset Validation Report
Generates the validation report required by the guide (Section 8) for every raw dataset:
Dataset Name, Source, Year, Rows, Columns, University Column, Country Column,
Important Indicators, Missing Values, Duplicate Rows, Duplicate Universities, Data Types
"""
import pandas as pd
import json

pd.set_option('display.max_columns', None)

report_lines = []

def log(line=""):
    print(line)
    report_lines.append(line)

def profile_dataset(name, path, source, year, uni_col, country_col, indicators, read_kwargs=None):
    log(f"\n{'='*80}")
    log(f"DATASET: {name}")
    log(f"{'='*80}")
    log(f"Source: {source}")
    log(f"Year: {year}")

    read_kwargs = read_kwargs or {}
    df = pd.read_csv(path, **read_kwargs)

    n_rows, n_cols = df.shape
    log(f"Rows: {n_rows}")
    log(f"Columns: {n_cols}")
    log(f"University Name Column: {uni_col}")
    log(f"Country Column: {country_col}")
    log(f"Important Indicators: {', '.join(indicators)}")

    # Missing values
    missing_pct = (df.isnull().mean() * 100).sort_values(ascending=False)
    top_missing = missing_pct[missing_pct > 0].head(10)
    log(f"\nColumns with Missing Values (top 10, %):")
    if len(top_missing) == 0:
        log("  None")
    else:
        for col, pct in top_missing.items():
            log(f"  {col}: {pct:.2f}%")

    # Duplicate rows
    dup_rows = df.duplicated().sum()
    log(f"\nDuplicate Rows (fully identical): {dup_rows}")

    # Duplicate universities (if applicable column exists)
    if uni_col and uni_col in df.columns:
        dup_unis = df[uni_col].duplicated().sum()
        log(f"Duplicate University Name entries: {dup_unis}")
    else:
        log("Duplicate University Name entries: N/A (no single university column, or country-level dataset)")

    # Data types
    log(f"\nData Types:")
    for col, dtype in df.dtypes.items():
        log(f"  {col}: {dtype}")

    return {
        "name": name,
        "source": source,
        "year": year,
        "rows": int(n_rows),
        "columns": int(n_cols),
        "university_column": uni_col,
        "country_column": country_col,
        "indicators": indicators,
        "duplicate_rows": int(dup_rows),
        "duplicate_universities": int(df[uni_col].duplicated().sum()) if uni_col and uni_col in df.columns else None,
        "missing_pct_top": top_missing.to_dict(),
        "columns_list": list(df.columns),
    }

results = []

# 1. QS World University Rankings 2025
results.append(profile_dataset(
    name="QS World University Rankings 2025",
    path="data/raw/qs_2025_raw.csv",
    source="Kaggle - QS World University Rankings 2025",
    year=2025,
    uni_col="Institution_Name",
    country_col="Location",
    indicators=["Academic_Reputation_Score", "Employer_Reputation_Score", "Faculty_Student_Score",
                "Citations_per_Faculty_Score", "International_Students_Score"]
))

# 2. THE World University Rankings 2024 (filtered from 2016-2026 file)
the_full = pd.read_csv("data/raw/the_2016_2026_raw.csv", encoding="utf-8-sig")
the_2024 = the_full[the_full["Year"].astype(str) == "2024"].copy()
the_2024.to_csv("data/raw/the_2024_filtered_raw.csv", index=False)
results.append(profile_dataset(
    name="THE World University Rankings 2024 (filtered from 2016-2026 source)",
    path="data/raw/the_2024_filtered_raw.csv",
    source="Kaggle - THE World University Rankings 2016-2026 (filtered to Year=2024). "
           "NOTE: Original file 'TIMES_WorldUniversityRankings_2024-selected-columns.csv' "
           "uploaded by user contained only headers, no data rows (confirmed empty on inspection). "
           "This filtered substitute was used instead, as documented and approved by user.",
    year=2024,
    uni_col="Name",
    country_col="Country",
    indicators=["Overall Score", "Teaching", "Research Environment", "Research Quality",
                "Industry Impact", "International Outlook", "Students to Staff Ratio", "International Students"]
))

# 3. World University Rankings 2023
results.append(profile_dataset(
    name="World University Rankings 2023",
    path="data/raw/wur_2023_raw.csv",
    source="Kaggle - World University Rankings 2023",
    year=2023,
    uni_col="Name of University",
    country_col="Location",
    indicators=["OverAll Score", "Teaching Score", "Research Score", "No of student",
                "No of student per staff", "International Student"]
))

# 4. World Bank Education Statistics (country-level, no university column)
results.append(profile_dataset(
    name="World Bank Education Statistics (EdStatsData)",
    path="data/raw/world_bank_edstats_data_raw.csv",
    source="World Bank EdStats (via Kaggle mirror)",
    year="1970-2085 (long format, multiple years as columns)",
    uni_col=None,
    country_col="Country Name",
    indicators=["Indicator Name", "Indicator Code", "yearly values 1970-2020 (historical)"]
))

with open("docs/validation_report_raw.json", "w") as f:
    json.dump(results, f, indent=2, default=str)

with open("docs/validation_report.txt", "w") as f:
    f.write("\n".join(report_lines))

print("\n\nValidation report saved to docs/validation_report.txt and docs/validation_report_raw.json")
