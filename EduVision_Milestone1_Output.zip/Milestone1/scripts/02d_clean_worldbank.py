"""
Module 2 - Clean World Bank Education Statistics
The raw file has 886,930 rows x 70 cols (3,665 indicators x ~240 countries, wide by year).
We deliberately select a documented, defensible subset of 7 core indicators relevant to the
Country Comparison dashboard (education expenditure, enrollment, literacy) rather than
loading all 3,665 indicators - per the guide's "do not force unrelated columns" principle.
"""
import pandas as pd

# Selected indicators - documented choice, not arbitrary
SELECTED_INDICATORS = {
    "SE.XPD.TOTL.GD.ZS": "Government Expenditure on Education (% of GDP)",
    "SE.TER.ENRR": "Tertiary Gross Enrolment Ratio (%)",
    "SE.TER.ENRR.FE": "Tertiary Gross Enrolment Ratio - Female (%)",
    "SE.ADT.LITR.ZS": "Adult Literacy Rate 15+ (%)",
    "SE.XPD.TERT.PC.ZS": "Govt Expenditure per Tertiary Student (% of GDP per capita)",
    "SE.PRM.ENRR": "Primary Gross Enrolment Ratio (%)",
    "SE.SEC.ENRR": "Secondary Gross Enrolment Ratio (%)",
}

# Real historical year columns only; 2020-2100 columns in this file are forward
# population projections unrelated to these education indicators (near-100% empty
# for education indicators, confirmed in Module 1 validation) - excluded deliberately.
YEAR_COLS = [str(y) for y in range(1970, 2018)]

usecols = ["Country Name", "Country Code", "Indicator Name", "Indicator Code"] + YEAR_COLS
df = pd.read_csv("data/raw/world_bank_edstats_data_raw.csv", usecols=usecols)
print("Loaded (all indicators):", df.shape)

df = df[df["Indicator Code"].isin(SELECTED_INDICATORS.keys())].copy()
print("Filtered to 7 selected indicators:", df.shape)

# Reshape wide (years as columns) -> long (Country, Year, Indicator, Value)
long_df = df.melt(
    id_vars=["Country Name", "Country Code", "Indicator Name", "Indicator Code"],
    value_vars=YEAR_COLS, var_name="Year", value_name="Value"
)
long_df["Year"] = long_df["Year"].astype(int)
before_dropna = len(long_df)
long_df = long_df.dropna(subset=["Value"])  # keep only years with an actual reported value
print(f"Long format: {before_dropna} rows -> {len(long_df)} rows with a real reported value")

# Standardize column names
long_df.columns = ["country_name", "country_code", "indicator_name", "indicator_code", "year", "value"]
long_df["country_name"] = long_df["country_name"].astype(str).str.strip()

# Merge country metadata (region, income group) for filtering later
country_meta = pd.read_csv("data/raw/world_bank_edstats_country_raw.csv",
                            usecols=["Country Code", "Short Name", "Region", "Income Group"])
country_meta.columns = ["country_code", "country_short_name", "region", "income_group"]
long_df = long_df.merge(country_meta, on="country_code", how="left")

# Flag rows with no region (these are aggregates like "World", "OECD members", not real countries)
is_aggregate = long_df["region"].isnull()
print(f"Rows belonging to non-country aggregates (e.g. 'World', 'Euro area'): {is_aggregate.sum()} "
      f"({is_aggregate.mean()*100:.1f}%) - kept but flagged via is_aggregate column, not dropped silently")
long_df["is_aggregate"] = is_aggregate

long_df.to_csv("data/cleaned/world_bank_education_cleaned.csv", index=False)
print("\nSaved: data/cleaned/world_bank_education_cleaned.csv | Final shape:", long_df.shape)
print("\nRows per indicator:")
print(long_df.groupby("indicator_name").size())
