"""
Build dim_university and dim_country master tables.
Matching rule (per guide Section 13-14): exact match on normalized_name + country only.
NO aggressive fuzzy matching across datasets - unmatched universities remain as separate
rows per source rather than being force-merged. This keeps the match honest and auditable.
"""
import pandas as pd

qs = pd.read_csv("data/cleaned/qs_2025_cleaned.csv")
the = pd.read_csv("data/cleaned/the_2024_cleaned.csv")
wur = pd.read_csv("data/cleaned/wur_2023_cleaned.csv")

qs_keys = qs[["university_name_key", "country_clean"]].rename(columns={"country_clean": "country"}).assign(source="QS2025")
the_keys = the[["university_name_key", "country_clean"]].rename(columns={"country_clean": "country"}).assign(source="THE2024")
wur_keys = wur[["university_name_key", "country_clean"]].rename(columns={"country_clean": "country"}).assign(source="WUR2023")

all_keys = pd.concat([qs_keys, the_keys, wur_keys], ignore_index=True)
all_keys = all_keys.dropna(subset=["university_name_key"])
all_keys = all_keys[all_keys["university_name_key"] != "nan"]

# Match key = name_key + country (exact match only, prevents false cross-country merges
# like the North-West University SA vs Northwest University China case found earlier)
all_keys["match_key"] = all_keys["university_name_key"] + "||" + all_keys["country"].astype(str).str.lower()

unique_unis = all_keys.drop_duplicates(subset=["match_key"])[["match_key", "university_name_key", "country"]].reset_index(drop=True)
unique_unis["university_id"] = ["U" + str(i+1).zfill(5) for i in range(len(unique_unis))]

# Which sources cover each university (for match-rate transparency, per guide Section 7)
sources_per_uni = all_keys.groupby("match_key")["source"].apply(lambda x: sorted(set(x))).reset_index()
unique_unis = unique_unis.merge(sources_per_uni, on="match_key", how="left")
unique_unis["in_qs"] = unique_unis["source"].apply(lambda s: isinstance(s, list) and "QS2025" in s)
unique_unis["in_the"] = unique_unis["source"].apply(lambda s: isinstance(s, list) and "THE2024" in s)
unique_unis["in_wur"] = unique_unis["source"].apply(lambda s: isinstance(s, list) and "WUR2023" in s)
unique_unis["num_sources"] = unique_unis[["in_qs", "in_the", "in_wur"]].sum(axis=1)

print("Total unique universities (dim_university):", len(unique_unis))
print("\nMatch coverage (how many datasets each university appears in):")
print(unique_unis["num_sources"].value_counts().sort_index())
print(f"\nIn all 3 datasets: {(unique_unis['num_sources']==3).sum()} "
      f"({(unique_unis['num_sources']==3).mean()*100:.1f}%)")
print(f"In exactly 2 datasets: {(unique_unis['num_sources']==2).sum()} "
      f"({(unique_unis['num_sources']==2).mean()*100:.1f}%)")
print(f"In only 1 dataset: {(unique_unis['num_sources']==1).sum()} "
      f"({(unique_unis['num_sources']==1).mean()*100:.1f}%)")

dim_university = unique_unis.rename(columns={"university_name_key": "university_name"})[
    ["university_id", "university_name", "country", "in_qs", "in_the", "in_wur", "num_sources"]
]
dim_university.to_csv("data/cleaned/dim_university.csv", index=False)

# --- dim_country ---
country_map = {
    "usa": "united states", "us": "united states", "united states of america": "united states",
    "uk": "united kingdom", "great britain": "united kingdom",
}
all_countries = pd.concat([
    qs["country_clean"], the["country_clean"], wur["country_clean"]
]).dropna().unique()
all_countries = sorted(set(all_countries))
dim_country = pd.DataFrame({"country": all_countries})
dim_country["country_id"] = ["C" + str(i+1).zfill(4) for i in range(len(dim_country))]
dim_country = dim_country[["country_id", "country"]]
dim_country.to_csv("data/cleaned/dim_country.csv", index=False)
print("\nTotal unique countries (dim_country):", len(dim_country))

# Save the match_key lookup for building fact tables next
all_keys.merge(unique_unis[["match_key", "university_id"]], on="match_key", how="left")[
    ["match_key", "university_id", "source"]
].drop_duplicates().to_csv("data/cleaned/_university_id_lookup.csv", index=False)
