"""Module 2 - Clean World University Rankings 2023"""
import pandas as pd
import re

df = pd.read_csv("data/raw/wur_2023_raw.csv")
print("BEFORE:", df.shape)

# 1. Remove blank junk rows (Rank='-' and Name is null) - confirmed not real data
df = df[~((df["University Rank"] == "-") & (df["Name of University"].isnull()))].copy()
print("After removing blank junk rows:", df.shape)

# 2. Standardize column names
df.columns = (df.columns.str.strip().str.lower()
              .str.replace(" ", "_").str.replace(":", "_"))

# 3. Clean university names (Category A critical identifier - investigate missing, don't fill)
df["name_of_university"] = df["name_of_university"].astype(str).str.strip()
df.loc[df["name_of_university"].isin(["nan", "None", ""]), "name_of_university"] = None
missing_names = df["name_of_university"].isnull().sum()
print(f"Rows with missing university name (kept, not dropped, flagged for review): {missing_names}")

df["university_name_key"] = (
    df["name_of_university"].astype(str).str.lower()
    .str.replace(r"[^\w\s]", "", regex=True)
    .str.replace(r"\s+", " ", regex=True)
    .str.strip()
)

# 4. Clean country/location names
df["location"] = df["location"].astype(str).str.strip()
country_map = {
    "usa": "united states", "us": "united states", "united states of america": "united states",
    "uk": "united kingdom", "great britain": "united kingdom",
    "south korea": "korea, south", "hong kong sar": "hong kong",
}
df["country_clean"] = df["location"].str.lower().str.strip().replace(country_map).str.title()

# 5. Numeric conversions - do NOT coerce blindly, "no_of_student" has commas e.g. "20,000"
for col in ["no_of_student", "no_of_student_per_staff"]:
    df[col] = pd.to_numeric(df[col].astype(str).str.replace(",", "", regex=False), errors="coerce")

df["international_student"] = pd.to_numeric(
    df["international_student"].astype(str).str.replace("%", "", regex=False), errors="coerce"
)

for col in ["teaching_score", "research_score"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# OverAll Score and University Rank use RANGE/BAND notation for lower-performing universities
# (e.g. "51.2-54.3" using an en-dash, or rank "1201-1400"). A band cannot become one true
# number, so split into an exact numeric field (NaN if banded) + a band label field,
# same approach used for QS 2025 rank bands - documented, not silently discarded.
def parse_numeric_or_band(val):
    s = str(val).strip()
    if re.fullmatch(r"\d+(\.\d+)?", s):
        return float(s), None
    if re.search(r"\d+(\.\d+)?\s*[-\u2013]\s*\d+(\.\d+)?", s):  # handles - and en-dash
        return None, s
    return None, None

parsed_score = df["overall_score"].apply(parse_numeric_or_band)
df["overall_score_numeric"] = parsed_score.apply(lambda x: x[0])
df["overall_score_band"] = parsed_score.apply(lambda x: x[1])
df = df.drop(columns=["overall_score"])

def parse_rank(val):
    s = str(val).strip()
    if re.fullmatch(r"\d+", s):
        return float(s), None, None
    if re.fullmatch(r"\d+\+", s):
        return None, s, None
    if re.search(r"\d+\s*[-\u2013]\s*\d+", s):  # handles - and en-dash bands
        return None, s, None
    if s.lower() == "reporter":
        return None, None, "reporter"  # submitted data, not numerically ranked
    return None, None, None

parsed_rank = df["university_rank"].apply(parse_rank)
df["university_rank_numeric"] = parsed_rank.apply(lambda x: x[0])
df["university_rank_band"] = parsed_rank.apply(lambda x: x[1])
df["university_rank_status"] = parsed_rank.apply(lambda x: x[2])

# Female:Male ratio -> female_pct
def parse_ratio(val):
    s = str(val)
    m = re.match(r"\s*(\d+)\s*:\s*(\d+)\s*", s)
    if m:
        f, m_ = int(m.group(1)), int(m.group(2))
        if f + m_ > 0:
            return round(f / (f + m_) * 100, 2)
    return None

df["female_pct"] = df["female_male_ratio"].apply(parse_ratio)

# 6. Duplicate check post-clean
dup_rows = df.duplicated().sum()
dup_names = df[df["name_of_university"].notnull()]["university_name_key"].duplicated().sum()
print(f"\nDuplicate rows: {dup_rows} | Duplicate university keys (excluding missing names): {dup_names}")

# 7. Missing value report - critical fields NOT filled with 0, just documented
missing_summary = df.isnull().mean() * 100
print("\nMissing % after cleaning (23% in scores is a REAL gap in source data - documented, not invented):")
print(missing_summary[missing_summary > 0])

df.to_csv("data/cleaned/wur_2023_cleaned.csv", index=False)
print("\nSaved: data/cleaned/wur_2023_cleaned.csv | Final shape:", df.shape)
