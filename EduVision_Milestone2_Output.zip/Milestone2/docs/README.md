# EduVision_DV - Milestone 2 Output
KPI Engineering and Dashboard Planning (Modules 3 & 4)

Depends on Milestone 1 output (dim_university, dim_country, cleaned datasets) — see that
package for the data foundation this builds on.

## data/final/
- `university_final_dataset.xlsx` — the Tableau-ready workbook, 8 sheets:
  KPI_Table, KPI_Documentation, dim_university, dim_country, fact_university_performance,
  fact_research, fact_student, fact_country_education
- `kpi_table_final.csv` — same KPI table as standalone CSV
- `fact_university_performance.csv`, `fact_research.csv`, `fact_student.csv` — standalone
  fact tables, linked via `university_id`

## scripts/
- `generate_education_kpis.py` — computes all 6 KPIs (required filename per project brief)
- `05_finalize_kpi_docs.py` — finalizes KPI table + generates documentation

## docs/
- `kpi_documentation.csv` — for each of the 6 KPIs: Source, Formula, Unit, Normalization,
  Missing-value treatment, Interpretation
- `dashboard_storyboard.pdf` / `.docx` — full field-level build spec for all 4 Tableau
  dashboards: KPI cards, chart types, exact fields, filters, navigation & filter-action flow

## The 6 KPIs and their real source (see kpi_documentation.csv for full detail)
1. Global Ranking — QS 2025 Rank (direct)
2. Research Impact Score — avg(THE Research Quality, WUR Research Score)
3. Faculty-to-Student Ratio — coalesce(WUR ratio, THE ratio) — real ratio, not a score
4. International Student % — coalesce(WUR %, THE %) — verified true percentages
5. Academic Reputation Score — QS Academic Reputation Score (direct)
6. Research Productivity Index — derived composite: 0.40×WUR Research + 0.30×THE Research
   Environment + 0.30×THE Research Quality (example weighting per guide Sec.24 — needs
   final approval, not yet production-final)

## What's NOT included (honest gap, not hidden)
- `eduvision_prototype.twbx` — the brief's Module 4 deliverable requires an actual Tableau
  file. Tableau Desktop/Public is not available in this environment, so this could not be
  produced. `dashboard_storyboard.pdf` is the complete spec to build it from.

## Known deviation carried over from Milestone 1
QS 2025 file has only 10 columns (not ~28 the guide assumes) — no Overall_Score or
Citations_per_Faculty_Score fields existed, so KPI 1 uses Rank instead of a 0-100 score,
and KPI 2/6 substitute THE/WUR research fields instead of QS citations. Documented in
kpi_documentation.csv column-by-column.
