"""
Milestone 2 / Module 3 - KPI Engineering
Builds fact_university_performance, fact_research, fact_student (linked via university_id)
and computes the 6 required KPIs with documented source, formula, unit per KPI.
"""
import pandas as pd

dim_university = pd.read_csv("data/cleaned/dim_university.csv")
lookup = pd.read_csv("data/cleaned/_university_id_lookup.csv")  # match_key -> university_id, source

qs = pd.read_csv("data/cleaned/qs_2025_cleaned.csv")
the = pd.read_csv("data/cleaned/the_2024_cleaned.csv")
wur = pd.read_csv("data/cleaned/wur_2023_cleaned.csv")

def attach_uid(df, name_key_col, country_col, source_tag):
    df = df.copy()
    df["match_key"] = df[name_key_col] + "||" + df[country_col].astype(str).str.lower()
    id_map = lookup[lookup["source"].str.contains(source_tag)][["match_key", "university_id"]].drop_duplicates("match_key")
    df = df.merge(id_map, on="match_key", how="left")
    return df

qs = attach_uid(qs, "university_name_key", "country_clean", "QS2025")
the = attach_uid(the, "university_name_key", "country_clean", "THE2024")
wur = attach_uid(wur, "university_name_key", "country_clean", "WUR2023")

print("QS rows with university_id matched:", qs["university_id"].notnull().sum(), "/", len(qs))
print("THE rows with university_id matched:", the["university_id"].notnull().sum(), "/", len(the))
print("WUR rows with university_id matched:", wur["university_id"].notnull().sum(), "/", len(wur))

# ---------------- fact_university_performance (QS-based) ----------------
fact_performance = qs[["university_id", "rank_2025_numeric", "rank_2025_band",
                        "academic_reputation_score", "status"]].copy()
fact_performance["year"] = 2025
fact_performance = fact_performance.rename(columns={
    "rank_2025_numeric": "global_rank_numeric",
    "rank_2025_band": "global_rank_band",
    "academic_reputation_score": "academic_reputation"
})
fact_performance.to_csv("data/cleaned/fact_university_performance.csv", index=False)
print("\nfact_university_performance:", fact_performance.shape)

# ---------------- fact_research (THE + WUR) ----------------
the_research = the[["university_id", "research_environment", "research_quality",
                     "industry_impact", "overall_score", "year"]].rename(columns={
    "overall_score": "the_overall_score"
})
wur_research = wur[["university_id", "research_score", "teaching_score",
                     "overall_score_numeric", "overall_score_band"]].copy()
wur_research["year"] = 2023

fact_research = the_research.merge(wur_research, on="university_id", how="outer", suffixes=("_the", "_wur"))
fact_research.to_csv("data/cleaned/fact_research.csv", index=False)
print("fact_research:", fact_research.shape)

# ---------------- fact_student (WUR + THE) ----------------
wur_student = wur[["university_id", "no_of_student", "no_of_student_per_staff",
                    "international_student", "female_pct"]].rename(columns={
    "no_of_student": "total_students_wur",
    "no_of_student_per_staff": "students_per_staff_wur",
    "international_student": "international_student_pct_wur"
})
the_student = the[["university_id", "student_population", "students_to_staff_ratio",
                    "international_students_pct", "female_pct"]].rename(columns={
    "student_population": "total_students_the",
    "students_to_staff_ratio": "students_per_staff_the",
    "international_students_pct": "international_student_pct_the",
    "female_pct": "female_pct_the"
})
fact_student = wur_student.merge(the_student, on="university_id", how="outer")
fact_student.to_csv("data/cleaned/fact_student.csv", index=False)
print("fact_student:", fact_student.shape)

# =========================================================================
# KPI ENGINEERING - 6 KPIs, each documented: source | formula | unit
# =========================================================================
kpi = dim_university[["university_id", "university_name", "country"]].copy()

# KPI 1: Global Ranking Score
# SOURCE: QS 2025 RANK_2025 (numeric where exact, band where ranged e.g. "601-610")
# FORMULA: direct pass-through of QS rank (lower = better). NOT rescaled to 0-100
#          because QS file in this project version has no Overall_Score column.
# UNIT: rank position (integer) or band label
kpi = kpi.merge(fact_performance[["university_id", "global_rank_numeric", "global_rank_band"]],
                 on="university_id", how="left")
kpi = kpi.rename(columns={"global_rank_numeric": "kpi1_global_ranking_rank",
                           "global_rank_band": "kpi1_global_ranking_band"})

# KPI 2: Research Impact Score
# SOURCE: THE Research Quality (2024) + WUR Research Score (2023), averaged where both exist
# FORMULA: mean(THE research_quality [0-100 scale], WUR research_score [0-100 scale])
# UNIT: index 0-100
research_join = fact_research[["university_id", "research_quality", "research_score"]]
kpi = kpi.merge(research_join, on="university_id", how="left")
kpi["kpi2_research_impact_score"] = kpi[["research_quality", "research_score"]].mean(axis=1, skipna=True)
kpi = kpi.drop(columns=["research_quality", "research_score"])

# KPI 3: Faculty-to-Student Ratio
# SOURCE: WUR 'No of student per staff' (2023) preferred; THE 'Students to Staff Ratio' (2024) as fallback
# FORMULA: coalesce(WUR ratio, THE ratio) - a REAL ratio, not a QS score
# UNIT: students per 1 faculty member
student_join = fact_student[["university_id", "students_per_staff_wur", "students_per_staff_the"]]
kpi = kpi.merge(student_join, on="university_id", how="left")
kpi["kpi3_faculty_student_ratio"] = kpi["students_per_staff_wur"].fillna(kpi["students_per_staff_the"])
kpi = kpi.drop(columns=["students_per_staff_wur", "students_per_staff_the"])

# KPI 4: International Student Percentage
# SOURCE: WUR 'International Student' (%) preferred; THE 'International Students' (%) as fallback
# FORMULA: coalesce(WUR pct, THE pct) - both sources ARE true percentages (verified in cleaning),
#          not scores - satisfies guide's rule against mislabeling scores as percentages
intl_join = fact_student[["university_id", "international_student_pct_wur", "international_student_pct_the"]]
kpi = kpi.merge(intl_join, on="university_id", how="left")
kpi["kpi4_international_student_pct"] = kpi["international_student_pct_wur"].fillna(kpi["international_student_pct_the"])
kpi = kpi.drop(columns=["international_student_pct_wur", "international_student_pct_the"])

# KPI 5: Academic Reputation Score
# SOURCE: QS 2025 Academic_Reputation_Score (direct, unmodified)
# FORMULA: direct pass-through
# UNIT: QS reputation index (as published)
kpi = kpi.merge(fact_performance[["university_id", "academic_reputation"]], on="university_id", how="left")
kpi = kpi.rename(columns={"academic_reputation": "kpi5_academic_reputation_score"})

# KPI 6: Research Productivity Index (DERIVED - documented composite, NOT Sustainability Score)
# SOURCE: WUR Research Score (2023) + THE Research Environment (2024) + THE Research Quality (2024)
# FORMULA: 0.40 * WUR_research_score + 0.30 * THE_research_environment + 0.30 * THE_research_quality
#          (example weighting per guide Section 24 - to be reviewed/approved by team before final use)
# UNIT: composite index 0-100
prod_join = fact_research[["university_id", "research_score", "research_environment", "research_quality"]]
kpi = kpi.merge(prod_join, on="university_id", how="left")
kpi["kpi6_research_productivity_index"] = (
    0.40 * kpi["research_score"].fillna(0) * (kpi["research_score"].notnull()) +
    0.30 * kpi["research_environment"].fillna(0) * (kpi["research_environment"].notnull()) +
    0.30 * kpi["research_quality"].fillna(0) * (kpi["research_quality"].notnull())
)
# Re-normalize weights when some components are missing (avoid penalizing missing data as zero)
weight_present = (0.40 * kpi["research_score"].notnull() +
                   0.30 * kpi["research_environment"].notnull() +
                   0.30 * kpi["research_quality"].notnull())
kpi["kpi6_research_productivity_index"] = kpi["kpi6_research_productivity_index"] / weight_present.replace(0, pd.NA)
kpi = kpi.drop(columns=["research_score", "research_environment", "research_quality"])

kpi.to_csv("data/cleaned/kpi_table.csv", index=False)
print("\nKPI table shape:", kpi.shape)
print("\nKPI completeness (non-null %):")
for c in kpi.columns:
    if c.startswith("kpi"):
        print(f"  {c}: {kpi[c].notnull().mean()*100:.1f}%")

print("\nSample rows:")
print(kpi.head(5).to_string())
