"""Milestone 2 / Module 3 - Finalize KPI table + build KPI documentation sheet"""
import pandas as pd

kpi = pd.read_csv("data/cleaned/kpi_table.csv")

# Combine KPI1 numeric+band into one readable field (both come from same QS source, mutually exclusive)
kpi["kpi1_global_ranking_display"] = kpi["kpi1_global_ranking_rank"].apply(
    lambda x: str(int(x)) if pd.notnull(x) else None
)
kpi.loc[kpi["kpi1_global_ranking_display"].isnull(), "kpi1_global_ranking_display"] = kpi["kpi1_global_ranking_band"]

# Reorder columns for the final deliverable
kpi_final = kpi[[
    "university_id", "university_name", "country",
    "kpi1_global_ranking_display", "kpi1_global_ranking_rank", "kpi1_global_ranking_band",
    "kpi2_research_impact_score",
    "kpi3_faculty_student_ratio",
    "kpi4_international_student_pct",
    "kpi5_academic_reputation_score",
    "kpi6_research_productivity_index",
]].copy()

kpi_final.to_csv("data/cleaned/kpi_table_final.csv", index=False)
print("Final KPI table:", kpi_final.shape)

# ---- KPI Documentation sheet (Source | Formula | Unit | Normalization | Missing-value treatment | Interpretation) ----
kpi_docs = pd.DataFrame([
    {
        "KPI": "1. Global Ranking Score",
        "Source": "QS World University Rankings 2025 - RANK_2025 field",
        "Formula": "Direct pass-through of published QS rank. Exact numeric rank kept where QS gives one "
                   "number; band label (e.g. '601-610') kept where QS gives a range instead of a single rank.",
        "Unit": "Global rank position (lower = better) or rank band label",
        "Normalization": "None applied - raw published rank preserved for accuracy",
        "Missing_Value_Treatment": "NULL for any university not present in QS 2025 (53.4% of merged pool) - "
                                    "not estimated or imputed",
        "Interpretation": "Lower number = higher global standing. Universities ranked 601+ are shown as a band, not a false single number.",
    },
    {
        "KPI": "2. Research Impact Score",
        "Source": "THE 2024 Research Quality + WUR 2023 Research Score (QS file in this project has "
                   "no Citations-per-Faculty field, so QS could not be used as originally planned - documented substitution)",
        "Formula": "mean(THE Research Quality, WUR Research Score), computed only over the sources that "
                   "have data for that university (not treated as zero if one source is missing)",
        "Unit": "Index, 0-100 scale",
        "Normalization": "Both source scores already 0-100 scale in original datasets - no rescaling needed",
        "Missing_Value_Treatment": "NULL if university appears in neither THE nor WUR",
        "Interpretation": "Higher = stronger research quality/output as measured by the two ranking bodies",
    },
    {
        "KPI": "3. Faculty-to-Student Ratio",
        "Source": "WUR 2023 'No of student per staff' (preferred) or THE 2024 'Students to Staff Ratio' (fallback)",
        "Formula": "coalesce(WUR ratio, THE ratio) - uses the actual reported ratio field, never a QS 'score'",
        "Unit": "Students per 1 faculty member",
        "Normalization": "None - real ratio value preserved as published",
        "Missing_Value_Treatment": "NULL if neither source reports it for that university",
        "Interpretation": "Lower ratio = more faculty attention per student (generally considered better)",
    },
    {
        "KPI": "4. International Student Percentage",
        "Source": "WUR 2023 'International Student' % (preferred) or THE 2024 'International Students' % (fallback)",
        "Formula": "coalesce(WUR pct, THE pct) - both fields verified during cleaning to be true percentages, "
                   "not scores, before use",
        "Unit": "Percent (%)",
        "Normalization": "None - true percentage as published",
        "Missing_Value_Treatment": "NULL if neither source reports it",
        "Interpretation": "Share of the student body that is international",
    },
    {
        "KPI": "5. Academic Reputation Score",
        "Source": "QS World University Rankings 2025 - Academic_Reputation_Score field",
        "Formula": "Direct pass-through, unmodified",
        "Unit": "QS reputation index as published",
        "Normalization": "None applied",
        "Missing_Value_Treatment": "NULL for universities not in QS 2025 (53.4% of merged pool)",
        "Interpretation": "Higher = stronger peer-reviewed academic reputation per QS survey",
    },
    {
        "KPI": "6. Research Productivity Index",
        "Source": "WUR 2023 Research Score + THE 2024 Research Environment + THE 2024 Research Quality "
                   "(derived composite - NOT Sustainability Score, per guide's explicit warning)",
        "Formula": "Weighted average: 0.40 x WUR Research Score + 0.30 x THE Research Environment + "
                   "0.30 x THE Research Quality. Weights are re-normalized when a component is missing "
                   "for a given university, so missing data is never scored as a zero. "
                   "NOTE: these weights are an example structure per guide Section 24 and require "
                   "final approval before being treated as production-final.",
        "Unit": "Composite index, 0-100 scale",
        "Normalization": "Component scores already 0-100 in source data",
        "Missing_Value_Treatment": "NULL only if ALL THREE components are missing for that university",
        "Interpretation": "Higher = stronger combined research output/environment/quality profile",
    },
])
kpi_docs.to_csv("docs/kpi_documentation.csv", index=False)
print("\nKPI documentation saved: docs/kpi_documentation.csv")
print(kpi_docs[["KPI", "Unit"]].to_string(index=False))
